CREATE PROCEDURE getStates()
  BEGIN
    SELECT state_id, state_code, state_name
    FROM state;
END;


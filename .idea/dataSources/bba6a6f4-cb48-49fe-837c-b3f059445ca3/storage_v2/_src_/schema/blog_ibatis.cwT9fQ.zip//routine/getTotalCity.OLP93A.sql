CREATE PROCEDURE getTotalCity(OUT total INT)
  BEGIN
    SELECT count(*) into total 
    FROM city;
END;


CREATE PROCEDURE getTotalCityStateId(IN stateId SMALLINT(6), OUT total_cities INT)
  BEGIN
    SELECT count(*) into total_cities 
    FROM city
    WHERE state_id = stateId;
END;


CREATE PROCEDURE getTotalCityStateId(IN stateId_id SMALLINT(6), OUT total INT)
  BEGIN
    SELECT count(*) into total
    FROM city
    WHERE state_id = stateId_id;
END;

